import { useMemo, useRef, useState, useEffect } from "react";

function App() {
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState("");
  const inputRefName = useRef();
  const inputRefSalary = useRef();
  const inputRefAge = useRef();
  const inputRefImage = useRef();

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      return item.toLowerCase().includes(query.toLowerCase());
    });
  }, [items, query]);

useEffect(() => {
  let config = {
    method: 'GET',
    redirect: 'follow'
  };
  
  fetch("https://dummy.restapiexample.com/api/v1/employees", config)
    .then(response => response.text())
    .then(result => console.log(result))
    .catch(error => console.log('error', error));
}, [])


  function onSubmit(e) {
    e.preventDefault();

    const name = inputRefName.current.value;
    if (name === "") return;
    setItems((prev) => {
      return [...prev, name];
    });

    inputRefName.current.value = "";
    const salary = inputRefSalary.current.value;
    if (salary === "") return;
    setItems((prev) => {
      return [...prev, salary];
    });

    inputRefSalary.current.value = "";
    const age = inputRefAge.current.value;
    if (age === "") return;
    setItems((prev) => {
      return [...prev, age];
    });

    inputRefAge.current.value = "";
    const image = inputRefImage.current.value;
    if (image === "") return;
    setItems((prev) => {
      return [...prev, image];
    });

    inputRefImage.current.value = "";

  }
  localStorage.setItem('myData', JSON.stringify(items));

  // Function for remove ---------------

  return (
    <>
      Search:
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        type="search"
      />
      <br />
      <br />
      <form onSubmit={onSubmit}>
        Employee Name: <input ref={inputRefName} type="text" />
        Employee Salary: <input ref={inputRefSalary} type="text" />
        Employee Age: <input ref={inputRefAge} type="text" />
        Employee Image: <input ref={inputRefImage} type="file" />
        <button type="submit">Add</button>
      </form>
      <h3>Items:</h3>
      {filteredItems.map((item, i) => (
        <div key={i}>{item}</div>
      ))}
    </>
  );
}

export default App;
